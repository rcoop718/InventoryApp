package com.zybooks.inventoryappryancooper;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class LoginScreenFragment extends Fragment {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin; // Login button
    private Button buttonRegister; // Registration button
    private DatabaseHelper databaseHelper;

    public LoginScreenFragment() {
        // Required empty public constructor
    }

    public static LoginScreenFragment newInstance(String param1, String param2) {
        LoginScreenFragment fragment = new LoginScreenFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    private void navigateToInventory() {
        Fragment inventoryFragment = new InventoryFragment(); // Replace with your InventoryFragment class
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.item_list_container, inventoryFragment)
                .commit();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseHelper = new DatabaseHelper(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login_screen, container, false);

        // Initialize UI elements
        editTextUsername = view.findViewById(R.id.etUsername);
        editTextPassword = view.findViewById(R.id.etPassword);
        buttonLogin = view.findViewById(R.id.btnLogin);
        buttonRegister = view.findViewById(R.id.btnRegister);

        // Set onClickListener for the login button
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                // Check user credentials
                if (databaseHelper.checkUser(username, password)) {
                    // User exists, proceed to login
                    Toast.makeText(getActivity(), "Login Successful", Toast.LENGTH_SHORT).show();
                    //navigateToInventory();
                    // Here, you can navigate to another Fragment or Activity as needed
                } else {
                    // User doesn't exist, show error
                    Toast.makeText(getActivity(), "Login Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Register button click listener
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                // User input validation
                if (username.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter a username", Toast.LENGTH_SHORT).show();
                    return; // Stop further execution
                }

                if (password.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter a password", Toast.LENGTH_SHORT).show();
                    return; // Stop further execution
                }

                // Add user to database
                databaseHelper.addUser(username, password);
                Toast.makeText(getActivity(), "Registration successful", Toast.LENGTH_SHORT).show();
                //navigateToInventory();

            }
        });

        return view;
    }
}