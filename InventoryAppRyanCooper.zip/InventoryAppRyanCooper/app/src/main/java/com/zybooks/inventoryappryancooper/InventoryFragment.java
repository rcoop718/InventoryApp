package com.zybooks.inventoryappryancooper;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryFragment extends Fragment {

    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<Item> inventoryItems;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);

        FloatingActionButton addButton = view.findViewById(R.id.add_inventory_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddItemDialog();
            }
        });

        recyclerView = view.findViewById(R.id.item_list);
        databaseHelper = new DatabaseHelper(getActivity());
        loadInventoryItems();

        adapter = new InventoryAdapter(inventoryItems, databaseHelper);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new InventoryAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Item item) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("item", item); // Assuming Item implements Serializable
                NavController navController = NavHostFragment.findNavController(InventoryFragment.this);
                navController.navigate(R.id.show_item_detail, bundle);
            }
        });

        return view;
    }

    private void loadInventoryItems() {
        inventoryItems = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM inventory", null);

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(DatabaseHelper.COLUMN_INVENTORY_ID));
                String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_INVENTORY_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_INVENTORY_QUANTITY));
                String description = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_INVENTORY_DESCRIPTION));

                Item item = new Item(id, name, description, quantity);
                inventoryItems.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
    }

    private void showAddItemDialog() {
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View promptView = layoutInflater.inflate(R.layout.dialog_add_inventory, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
        alertDialogBuilder.setView(promptView);

        final EditText editTextName = promptView.findViewById(R.id.etItemName);
        final EditText editTextQuantity = promptView.findViewById(R.id.etQuantity);
        final EditText editTextDescription = promptView.findViewById(R.id.etDescription);

        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        String name = editTextName.getText().toString();
                        int quantity = Integer.parseInt(editTextQuantity.getText().toString());
                        String description = editTextDescription.getText().toString();
                        addNewItemToDatabase(name, quantity, description);
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }

    private void addNewItemToDatabase(String name, int quantity, String description) {
        long itemId = databaseHelper.addInventoryItem(name, quantity, description);
        Item newItem = new Item(itemId, name, description, quantity);
        inventoryItems.add(newItem);
        adapter.notifyItemInserted(inventoryItems.size() - 1);
    }
    
}