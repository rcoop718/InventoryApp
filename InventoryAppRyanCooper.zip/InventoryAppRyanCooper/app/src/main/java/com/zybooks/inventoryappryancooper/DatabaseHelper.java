package com.zybooks.inventoryappryancooper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Information
    private static final String DATABASE_NAME = "AppDatabase";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USER_NAME = "username";
    private static final String COLUMN_USER_PASSWORD = "password";

    // Inventory Table
    private static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_INVENTORY_ID = "id";
    public static final String COLUMN_INVENTORY_NAME = "name";
    public static final String COLUMN_INVENTORY_QUANTITY = "quantity";
    public static final String COLUMN_INVENTORY_DESCRIPTION = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_NAME + " TEXT,"
                + COLUMN_USER_PASSWORD + " TEXT" + ")";

        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                + COLUMN_INVENTORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_INVENTORY_NAME + " TEXT,"
                + COLUMN_INVENTORY_QUANTITY + " INTEGER,"
                + COLUMN_INVENTORY_DESCRIPTION + " TEXT" + ")";

        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // User Operations
    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, username);
        values.put(COLUMN_USER_PASSWORD, password);
        db.insert(TABLE_USERS, null, values);
        db.close();
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COLUMN_USER_ID };
        String selection = COLUMN_USER_NAME + " =? AND " + COLUMN_USER_PASSWORD + " =?";
        String[] selectionArgs = { username, password };
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count > 0;
    }

    // Inventory Operations
    public long addInventoryItem(String name, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INVENTORY_NAME, name);
        values.put(COLUMN_INVENTORY_QUANTITY, quantity);
        values.put(COLUMN_INVENTORY_DESCRIPTION, description);
        long id = db.insert(TABLE_INVENTORY, null, values);
        db.close();
        return id; // Return the new row ID
    }

    public Item getItem(int itemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Item item = null;

        Cursor cursor = db.query(
                "inventory", // Table name
                new String[]{"id", "name", "description", "quantity"}, // Columns to return
                "id = ?", // Selection criteria
                new String[]{String.valueOf(itemId)}, // Selection arguments
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            long id = cursor.getLong(cursor.getColumnIndex("id"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String description = cursor.getString(cursor.getColumnIndex("description"));
            int quantity = cursor.getInt(cursor.getColumnIndex("quantity"));

            item = new Item(id, name, description, quantity);
            cursor.close();
        }

        db.close();
        return item;
    }

    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
    }

    public void updateInventoryItem(int id, String name, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INVENTORY_NAME, name);
        values.put(COLUMN_INVENTORY_QUANTITY, quantity);
        values.put(COLUMN_INVENTORY_DESCRIPTION, description);
        db.update(TABLE_INVENTORY, values, COLUMN_INVENTORY_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    public void deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INVENTORY, COLUMN_INVENTORY_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    public void updateItemQuantity(long id, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INVENTORY_QUANTITY, newQuantity);

        // Check if quantity has reached zero
        if (newQuantity == 0) {
            sendSmsNotification(itemName);
        }

        // Update only the quantity of the item with the specified ID
        db.update(TABLE_INVENTORY, values, COLUMN_INVENTORY_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }
}


