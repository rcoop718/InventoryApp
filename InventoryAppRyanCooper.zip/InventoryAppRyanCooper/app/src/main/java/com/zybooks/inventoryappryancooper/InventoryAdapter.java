package com.zybooks.inventoryappryancooper;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private List<Item> inventoryItems;
    private DatabaseHelper databaseHelper;
    private OnItemClickListener listener;

    // Constructor
    public InventoryAdapter(List<Item> inventoryItems, DatabaseHelper databaseHelper) {
        this.inventoryItems = inventoryItems;
        this.databaseHelper = databaseHelper;
    }

    // Interface for click events
    public interface OnItemClickListener {
        void onItemClick(Item item);
    }

    // Set the listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item item = inventoryItems.get(position);
        holder.textViewName.setText(item.getName());

        // Item click listener
        holder.itemView.setOnClickListener(v -> {
            if (listener != null && position != RecyclerView.NO_POSITION) {
                listener.onItemClick(inventoryItems.get(position));
            }
        });

        // Delete button click listener
        holder.deleteButton.setOnClickListener(v -> {
            int currentPosition = holder.getAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                removeItem(currentPosition);
            }
        });
    }

    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }

    // Remove an item from the list
    private void removeItem(int position) {
        Item item = inventoryItems.get(position);
        databaseHelper.deleteInventoryItem((int) item.getId());
        inventoryItems.remove(position);
        notifyItemRemoved(position);
    }

    // ViewHolder class
    class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName;
        Button deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.tvitem_name);
            deleteButton = itemView.findViewById(R.id.delete_button);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onItemClick(inventoryItems.get(position));
                }
            });
        }
    }
}
