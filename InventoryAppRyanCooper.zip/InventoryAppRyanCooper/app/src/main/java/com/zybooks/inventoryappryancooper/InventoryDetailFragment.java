package com.zybooks.inventoryappryancooper;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class InventoryDetailFragment extends Fragment {

    private Item currentItem;
    private DatabaseHelper databaseHelper;

    public InventoryDetailFragment() {
        // Required empty public constructor
    }

    public static InventoryDetailFragment newInstance(Item item) {
        InventoryDetailFragment fragment = new InventoryDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable("item", item); // Ensure Item implements Serializable
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        // Get the item from the arguments
        if (getArguments() != null) {
            currentItem = (Item) getArguments().getSerializable("item");
        }

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(requireContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory_detail, container, false);
        displayItemDetails(view);
        return view;
    }


    private void displayItemDetails(View view) {
        TextView itemName = view.findViewById(R.id.item_name);
        TextView itemDescription = view.findViewById(R.id.item_description);
        TextView itemQuantity = view.findViewById(R.id.item_quantity);

        itemName.setText(currentItem.getName());
        itemDescription.setText(currentItem.getDescription());
        itemQuantity.setText(String.valueOf(currentItem.getQuantity()));

        setupQuantityButtons(view);
    }

    private void setupQuantityButtons(View view) {
        Button decreaseButton = view.findViewById(R.id.decrease_button);
        decreaseButton.setOnClickListener(v -> changeQuantity(-1));

        Button increaseButton = view.findViewById(R.id.increase_button);
        increaseButton.setOnClickListener(v -> changeQuantity(1));
    }

    private void changeQuantity(int delta) {
        int currentQuantity = currentItem.getQuantity() + delta;
        if (currentQuantity >= 0) {
            currentItem.setQuantity(currentQuantity);
            TextView itemQuantityTextView = getView().findViewById(R.id.item_quantity);
            itemQuantityTextView.setText(String.valueOf(currentQuantity));

            // Update the quantity in the database
            if (databaseHelper != null) {
                databaseHelper.updateItemQuantity(currentItem.getId(), currentQuantity);
            }
        }
    }
}